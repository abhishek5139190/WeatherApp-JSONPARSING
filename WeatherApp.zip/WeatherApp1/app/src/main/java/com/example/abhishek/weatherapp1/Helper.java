package com.example.abhishek.weatherapp1;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * Created by Abhishek on 11-05-2016.
 */
public class Helper {

    public static String convertLongDateToFormattedString(long timeInMillis, String format) {
        Date date = new Date(timeInMillis * 1000);
        Date today = new Date();
        GregorianCalendar gc = new GregorianCalendar();
        gc.add(Calendar.DATE, 1);
        Date tomorrow = gc.getTime();

        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        if (sdf.format(date).equals(sdf.format(today))) {
            return "Today";
        } else if (sdf.format(date).equals(sdf.format(tomorrow))) {
            return "Tomorrow";
        } else {
            sdf = new SimpleDateFormat(format, Locale.getDefault());
            return sdf.format(date);
        }
    }

    public static String convertLongDateToDateAndMonthString(long timeInMillis) {
        Date date = new java.util.Date(timeInMillis * 1000);
        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat("MMMM dd", Locale.getDefault());
        return sdf.format(date);
    }

    public static int getIconResourceFromString(String iconString) {
        switch (iconString) {
            case "01d":
            case "01n":
                return R.drawable.art_clear;
            case "02d":
            case "02n":
                return R.drawable.art_light_clouds;
            case "03d":
            case "03n":
                return R.drawable.art_light_clouds;
            case "04d":
            case "04n":
                return R.drawable.art_clouds;
            case "09d":
            case "09n":
                return R.drawable.art_light_rain;
            case "10d":
            case "10n":
                return R.drawable.art_rain;
            case "11d":
            case "11n":
                return R.drawable.art_storm;
            case "13d":
            case "13n":
                return R.drawable.art_snow;
            case "50d":
            case "50n":
                return R.drawable.art_fog;
            default:
                return R.drawable.art_clear;
        }
    }

    public static String convertTempToFormattedTemp(double temp) {
        String formattedTemp = String.valueOf((int) temp);
        formattedTemp = formattedTemp.concat("\u00B0");
        return formattedTemp;
    }
}
