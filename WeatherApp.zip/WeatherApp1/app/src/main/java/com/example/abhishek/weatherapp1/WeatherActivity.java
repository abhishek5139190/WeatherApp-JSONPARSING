package com.example.abhishek.weatherapp1;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by Abhishek on 11-05-2016.
 */
public class WeatherActivity extends AppCompatActivity{
      TextView cityName;
        ListView weatherListView;
        ProgressBar progressBar;
        List<Weather> weatherList = new ArrayList<>();
        WeatherListAdapter weatherListAdapter;
        SharedPreferences prefs;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setLogo(R.drawable.ic_icon);
            toolbar.setTitle("");
        }
        setSupportActionBar(toolbar);

        cityName = (TextView) findViewById(R.id.cityName);
        weatherListView = (ListView) findViewById(R.id.weatherListView);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        prefs = getSharedPreferences("weather_info", MODE_PRIVATE);

        cityName.setText(prefs.getString("cityDisplayed", prefs.getString("city", "Delhi")));

        FetchWeatherInfo fetchWeatherInfo = new FetchWeatherInfo(WeatherActivity.this);
        fetchWeatherInfo.execute();
    }

    public void setWeatherList(List<Weather> obj) {
        weatherList = obj;
        weatherListAdapter = new WeatherListAdapter(WeatherActivity.this, weatherList);
        weatherListView.setAdapter(weatherListAdapter);

        weatherListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), DetailActivity.class);
                intent.putExtra("weatherObj", weatherList.get(position));
                startActivity(intent);
            }
        });

        cityName.setText(prefs.getString("cityDisplayed", prefs.getString("city", "Delhi")));
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        getMenuInflater().inflate(R.menu.menu_weather, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        
        int id = item.getItemId();

        
        if (id == R.id.action_settings) {
            Intent intent = new Intent(getApplicationContext(), SettingActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

}
