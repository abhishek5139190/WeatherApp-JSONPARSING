package com.example.abhishek.weatherapp1;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
/**
 * Created by Abhishek on 11-05-2016.
 */
public class SettingActivity extends AppCompatActivity
        implements GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks {

    private String LOG_TAG = SettingActivity.class.getSimpleName();
//gobaby rock the show.
    private EditText mLocation, mDays;
    private ImageView mDetectLocation;

    private SharedPreferences prefs;
    private SharedPreferences.Editor edit;

    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;

    double mLatitude, mLongitude;

    String mCityName = "Location Not Available";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (toolbar != null) {
            toolbar.setLogo(R.drawable.ic_settings_white_36dp);
            toolbar.setTitle("Settings");
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mLocation = (EditText) findViewById(R.id.location);
        mDays = (EditText) findViewById(R.id.days);
        mDetectLocation = (ImageView) findViewById(R.id.detect_location);

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addOnConnectionFailedListener(this)
                .addConnectionCallbacks(this)
                .build();

        prefs = getSharedPreferences("weather_info", MODE_PRIVATE);
        mDays.setText(String.valueOf(prefs.getInt("number_of_days", 16)));

        mDetectLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLocation.setText(mCityName);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mGoogleApiClient.connect();
    }

    @Override
    protected void onStop() {
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
        super.onStop();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
          
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            mLatitude = mLastLocation.getLatitude();
            mLongitude = mLastLocation.getLongitude();
            Geocoder gcd = new Geocoder(getApplicationContext(), Locale.getDefault());
            List<Address> addresses = null;
            try {
                addresses = gcd.getFromLocation(mLatitude, mLongitude, 1);
                if (addresses.size() > 0) {
                    Log.i("add: AddressLine 0", addresses.get(0).getAddressLine(0));
                    Log.i("add: AddressLine 1", addresses.get(0).getAddressLine(1));
                    Log.i("add: AddressLine 2", addresses.get(0).getAddressLine(2));
                    Log.i("add: AddressLine 3", addresses.get(0).getAddressLine(3));
                    Log.i("add: AdminArea", addresses.get(0).getAdminArea());
                    Log.i("add: CountryCode", addresses.get(0).getCountryCode());
                    Log.i("add: CountryName", addresses.get(0).getCountryName());
                    Log.i("add: FeatureName", addresses.get(0).getFeatureName());
                    Log.i("add: Locality", addresses.get(0).getLocality());
                    Log.i("add: Postal Code", addresses.get(0).getPostalCode());
                    Log.i("add: SubAdminArea", addresses.get(0).getSubAdminArea());
                    Log.i("add: SubLocality", addresses.get(0).getSubLocality());

                    mCityName = addresses.get(0).getSubLocality();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(LOG_TAG, "Connection Suspended");
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.i(LOG_TAG, "Connection Failed: " + connectionResult.getErrorMessage());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_setting, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
     
        int id = item.getItemId();

        edit = prefs.edit();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_done) {
            boolean flag = true;
            if (!mLocation.getText().toString().equals(""))
                edit.putString("city", mLocation.getText().toString());
            if (!mDays.getText().toString().equals("")) {
                int noOfDays = Integer.valueOf(mDays.getText().toString());
                if (noOfDays < 1 || noOfDays > 16) {
                    mDays.setError("Invalid Number of Days");
                    Toast.makeText(getApplicationContext(), "Days must be between 1 and 16", Toast.LENGTH_SHORT).show();
                    flag = false;
                } else {
                    edit.putInt("number_of_days", noOfDays);
                }
            }
            edit.apply();

            if (flag) {
                Intent intent = new Intent(getApplicationContext(), WeatherActivity.class);
                startActivity(intent);
            }
        }

        return super.onOptionsItemSelected(item);
    }

}
