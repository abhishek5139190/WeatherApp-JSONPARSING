package com.example.abhishek.weatherapp1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Abhishek on 11-05-2016.
 */
public class DetailActivity extends AppCompatActivity {

    TextView day, date, min, max, condition, humidity, pressure, wind, rain;
    ImageView icon;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        final Weather weather = (Weather) getIntent().getSerializableExtra("weatherObj");
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (toolbar != null) {
            toolbar.setLogo(R.drawable.ic_icon_small);
            toolbar.setTitle(Helper.convertLongDateToFormattedString(weather.getDate(), "EEEE, d MMM"));
        }

        prefs = getSharedPreferences("weather_info", MODE_PRIVATE);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        assert fab != null;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String message = "Weather Info from Weather App: \nCity; " +
                        prefs.getString("cityDisplayed", "Delhi") +
                        "\nDate: " + Helper.convertLongDateToFormattedString(weather.getDate(), "EEEE, d MMM") +
                        "\nWeather Conditions: " + weather.getWeatherDesc() +
                        "\nMax Temp: " + Helper.convertTempToFormattedTemp(weather.getTempMax()) +
                        "\nMin Temp: " + Helper.convertTempToFormattedTemp(weather.getTempMin());

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, message);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        day = (TextView) findViewById(R.id.day);
        date = (TextView) findViewById(R.id.date);
        min = (TextView) findViewById(R.id.min);
        max = (TextView) findViewById(R.id.max);
        condition = (TextView) findViewById(R.id.condition);
        humidity = (TextView) findViewById(R.id.humidity);
        pressure = (TextView) findViewById(R.id.pressure);
        wind = (TextView) findViewById(R.id.wind);
        rain = (TextView) findViewById(R.id.rain);
        icon = (ImageView) findViewById(R.id.icon);

        day.setText(Helper.convertLongDateToFormattedString(weather.getDate(), "EEEE"));
        date.setText(Helper.convertLongDateToDateAndMonthString(weather.getDate()));
        min.setText(Helper.convertTempToFormattedTemp(weather.getTempMin()));
        max.setText(Helper.convertTempToFormattedTemp(weather.getTempMax()));
        condition.setText(weather.getWeatherMain());
        humidity.setText("Humidity: " + weather.getHumidity() + "%");
        pressure.setText("Pressure: " + weather.getPressure() + " hPa");
        wind.setText("Wind: " + weather.getSpeed() + " km/hr");
        rain.setText("Rain: " + weather.getRain() + " mm");
        icon.setImageResource(Helper.getIconResourceFromString(weather.getWeatherIcon()));
    }
}

