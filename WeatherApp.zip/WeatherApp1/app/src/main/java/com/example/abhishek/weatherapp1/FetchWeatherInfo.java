package com.example.abhishek.weatherapp1;


import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Abhishek on 11-05-2016.
 */
public class FetchWeatherInfo extends AsyncTask<Void, Void, List<Weather>> {

    final String KEY_CITY = "city";
    final String KEY_CITY_NAME = "name";
    final String KEY_CODE = "cod";
    final String KEY_MESSAGE = "message";
    final String KEY_COUNT = "cnt";
    final String KEY_LIST = "list";

    final String KEY_DATE = "dt";
    final String KEY_TEMP = "temp";
    final String KEY_TEMP_DAY = "day";
    final String KEY_TEMP_MIN = "min";
    final String KEY_TEMP_MAX = "max";
    final String KEY_TEMP_NIGHT = "night";
    final String KEY_TEMP_EVE = "eve";
    final String KEY_TEMP_MORN = "morn";

    final String KEY_PRESSURE = "pressure";
    final String KEY_HUMIDITY = "humidity";
    final String KEY_WEATHER = "weather";
    final String KEY_WEATHER_MAIN = "main";
    final String KEY_WEATHER_DESC = "description";
    final String KEY_WEATHER_ICON = "icon";

    final String KEY_SPEED = "speed";
    final String KEY_CLOUDS = "clouds";
    final String KEY_RAIN = "rain";

    String LOG_TAG = FetchWeatherInfo.class.getSimpleName();
    WeatherActivity weatherActivity;

    SharedPreferences prefs;
    SharedPreferences.Editor edit;

    public FetchWeatherInfo(WeatherActivity context) {
        weatherActivity = context;
    }

    @Override
    protected List<Weather> doInBackground(Void... params) {

        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String weatherJsonStr;
        List<Weather> weatherList = new ArrayList<>();
        prefs = weatherActivity.getSharedPreferences("weather_info", Context.MODE_PRIVATE);
        edit = prefs.edit();
        String cityName = prefs.getString("city", "Delhi");
        int noOfDays = prefs.getInt("number_of_days", 16);

        try {
            String base_uri = "http://api.openweathermap.org/data/2.5/forecast/daily?";
            Uri builtUri = Uri.parse(base_uri).buildUpon()
                    .appendQueryParameter("q", cityName)
                    .appendQueryParameter("mode", "json")
                    .appendQueryParameter("units", "metric")
                    .appendQueryParameter("cnt", String.valueOf(noOfDays))
                    .appendQueryParameter("appid", "d634aef8960e6aa482a9ebc7fef4d46d").build();

            URL url = new URL(builtUri.toString());

            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            Log.i(LOG_TAG, builtUri.toString());

            InputStream inputStream = urlConnection.getInputStream();
            StringBuilder buffer = new StringBuilder();
            if (inputStream == null) {
                return null;
            }
            reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line).append("\n");
            }
            if (buffer.length() == 0) {
                return null;
            }
            weatherJsonStr = buffer.toString();
            getWeatherFromJson(weatherJsonStr, weatherList);
        } catch (IOException e) {
            Log.e(LOG_TAG, "Error ", e);
        } catch (JSONException e) {
            Log.e(LOG_TAG, e.getMessage(), e);
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e(LOG_TAG, "Error closing stream", e);
                }
            }
        }
        return weatherList;
    }

    private void getWeatherFromJson(String weatherJsonStr, List<Weather> weatherList) throws JSONException {
        try {
            JSONObject weatherJSONObject = new JSONObject(weatherJsonStr);

            JSONObject city = weatherJSONObject.getJSONObject(KEY_CITY);

            String cityName = city.getString(KEY_CITY_NAME);

            edit.putString("cityDisplayed", cityName);
            edit.apply();

            int code = weatherJSONObject.getInt(KEY_CODE);
            double message = weatherJSONObject.getDouble(KEY_MESSAGE);
            int count = weatherJSONObject.getInt(KEY_COUNT);

            JSONArray weatherListArray = weatherJSONObject.getJSONArray(KEY_LIST);

            for (int i = 0; i < weatherListArray.length(); i++) {
                JSONObject weatherDayObject = weatherListArray.getJSONObject(i);
                Weather weather = new Weather();

                weather.setDate(weatherDayObject.getLong(KEY_DATE));
                JSONObject temp = weatherDayObject.getJSONObject(KEY_TEMP);
                weather.setTempDay(temp.getDouble(KEY_TEMP_DAY));
                weather.setTempMin(temp.getDouble(KEY_TEMP_MIN));
                weather.setTempMax(temp.getDouble(KEY_TEMP_MAX));
                weather.setTempNight(temp.getDouble(KEY_TEMP_NIGHT));
                weather.setTempEve(temp.getDouble(KEY_TEMP_EVE));
                weather.setTempMorn(temp.getDouble(KEY_TEMP_MORN));

                weather.setPressure(weatherDayObject.getDouble(KEY_PRESSURE));
                weather.setHumidity(weatherDayObject.getDouble(KEY_HUMIDITY));
                JSONArray weatherInfo = weatherDayObject.getJSONArray(KEY_WEATHER);
                for (int j = 0; j < weatherInfo.length(); j++) {
                    JSONObject weatherObject = weatherInfo.getJSONObject(j);
                    weather.setWeatherMain(weatherObject.getString(KEY_WEATHER_MAIN));
                    weather.setWeatherDesc(weatherObject.getString(KEY_WEATHER_DESC));
                    weather.setWeatherIcon(weatherObject.getString(KEY_WEATHER_ICON));
                }

                weather.setSpeed(weatherDayObject.getDouble(KEY_SPEED));
                weather.setClouds(weatherDayObject.getInt(KEY_CLOUDS));
                if (weatherDayObject.has(KEY_RAIN)) {
                    weather.setRain(weatherDayObject.getDouble(KEY_RAIN));
                }
                weatherList.add(weather);
            }
        } catch (JSONException e) {
            Log.e(LOG_TAG, e.getMessage(), e);
            e.printStackTrace();
        }
    }

    @Override
    protected void onPostExecute(List<Weather> result) {
        weatherActivity.setWeatherList(result);
    }
}