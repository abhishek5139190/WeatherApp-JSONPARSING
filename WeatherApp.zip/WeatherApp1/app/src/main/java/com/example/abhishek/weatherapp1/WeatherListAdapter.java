package com.example.abhishek.weatherapp1;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;


/**
 * Created by Abhishek on 11-05-2016.
 */
public class WeatherListAdapter extends ArrayAdapter<Weather>  {


        private LayoutInflater vi;

        public static class ViewHolder {
            public final TextView date;
            public final TextView condition;
            public final TextView min;
            public final TextView max;
            public final ImageView icon;

            public ViewHolder(View view) {
                date = (TextView) view.findViewById(R.id.date);
                condition = (TextView) view.findViewById(R.id.condition);
                min = (TextView) view.findViewById(R.id.min);
                max = (TextView) view.findViewById(R.id.max);
                icon = (ImageView) view.findViewById(R.id.icon);
            }
        }

        public WeatherListAdapter(Context context, List<Weather> items) {
        super(context, R.layout.weather_row_layout, items);
    }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

        View view = convertView;
        if (view == null) {
            vi = LayoutInflater.from(getContext());
            view = vi.inflate(R.layout.weather_row_layout, null);
        }

        final ViewHolder viewHolder = new ViewHolder(view);
        Weather item = getItem(position);

        int iconResource = Helper.getIconResourceFromString(item.getWeatherIcon());
        viewHolder.icon.setImageResource(iconResource);

        viewHolder.date.setText(Helper.convertLongDateToFormattedString(item.getDate(), "EEEE, d MMM"));
        viewHolder.condition.setText(String.valueOf(item.getWeatherMain()));
        viewHolder.min.setText(Helper.convertTempToFormattedTemp(item.getTempMin()));
        viewHolder.max.setText(Helper.convertTempToFormattedTemp(item.getTempMax()));
        return view;
    }




}
